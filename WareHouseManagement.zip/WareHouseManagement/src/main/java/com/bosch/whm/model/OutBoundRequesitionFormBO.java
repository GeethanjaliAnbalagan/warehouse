package com.bosch.whm.model;

import java.util.ArrayList;
import java.util.List;

public class OutBoundRequesitionFormBO {


	List<InBoundRequesitionForm> list=new ArrayList<InBoundRequesitionForm>();
	public List<String> getLocation()//epic4
	{
		return null;  //display the various locations where the product is stored along with the qty}
	}
	public void outBoundLocationScan()//epic4

	{//1.If the scanned location code doesn’t match with the blocked location details, display an error message on the screen.    }
	}  public void productScan()//epic4
	{            //System should validate the scanned product, location details with the outbound requisition form            }

	}

	public void confirmLocation()//epic4

	{
		//  logic related to the user to save the details once the user confirms it.
	} 
}


package com.bosch.whm.model;

public class LocationAnalyzer {
	
    private int S_no;
    private int lane;
    private int shelf;
    private int rack;
    private int robotHoldingCapacity;


   
    public LocationAnalyzer(){}

    //Create Parameterized constructor
 
    //Create getter setter with toString

 
    



}






        
        
        
        
        
        
       

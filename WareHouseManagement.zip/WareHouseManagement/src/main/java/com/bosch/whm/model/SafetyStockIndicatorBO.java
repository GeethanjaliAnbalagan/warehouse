package com.bosch.whm.model;

import java.util.List;

public class SafetyStockIndicatorBO {
	public String productStorkStored() {
		
		//minimum stock level
			
		//supplier deliver time 
			return null;
	
			// to be stored in the system.
		}
		
		
		public List<Product> getAllThreshold() {
			return null;
			
			//Threshold for each product to be defined

		}
		
		
		public String sendMail() {
		
			//If the current stock is less than the required stock, a mail must be done
			//smtp mail
		//Mail-server is configured to send mail
			
			//mail should contain
			
			// the product details, supplier 
			//details, current count etc.

			return null;
			
		}
}


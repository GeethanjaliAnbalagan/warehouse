package com.bosch.whm.service;

public class ProductInBoundBOService {
	//implement all methods of ProductInBoundBO
}

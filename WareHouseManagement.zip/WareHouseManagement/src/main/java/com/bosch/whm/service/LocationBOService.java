package com.bosch.whm.service;

public class LocationBOService {
	//implement all methods of LocationBO
}

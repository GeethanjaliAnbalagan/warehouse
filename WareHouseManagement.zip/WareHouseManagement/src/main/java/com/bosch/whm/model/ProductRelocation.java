package com.bosch.whm.model;

import java.io.*;
import java.util.Date;

public class ProductRelocation  
{

   private String RelocationReason;
     private String ProductName;
   private int ProductCode;
    private int Batchno;
    private Dimension dimension;
     private int weight;
    private  int orderNo;
     private Date Delivery;         
   
//include getters and setters     
// create required constructors


      }

package com.bosch.whm.model;

public class Location {
	
    private int locationId;
    private String description;
    private Dimension dimension;
    private int statusCode; 
 

    
    

	}

}

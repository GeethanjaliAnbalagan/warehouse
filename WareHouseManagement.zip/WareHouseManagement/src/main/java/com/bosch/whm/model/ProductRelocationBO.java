package com.bosch.whm.model;

import java.util.ArrayList;
import java.util.List;

public class ProductRelocationBO  
{


	List<LocationAnalyzer> list=new ArrayList<LocationAnalyzer>();

	public String updateProductLocation(LocationAnalyzer location)//epic 3
	{
		return null;

		// update the product’s location details.
	}

//  the location details are correct and if there is place 
		//available in the required rack for the product
	public int availabilityCheck(LocationAnalyzer LocationAnalyzer) //epic 3
	{
		return 0;
	}



	//epic3
	//logic related to the user to save the details once the user confirms it.need to call ProductBo method
	
	public void confirmDetails(String confirm)


	{

		
		
	}   




}


















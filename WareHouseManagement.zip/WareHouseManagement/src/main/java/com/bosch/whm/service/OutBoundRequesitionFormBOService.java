package com.bosch.whm.service;

public class OutBoundRequesitionFormBOService {
	//implement all methods of OutBoundRequesitionFormBO
}

package com.bosch.whm.service;

public class InventoryMasterBOService {
	//implement all methods of InventoryMasterBO
}

package com.bosch.whm.model;

public class Truck {

	
	private int truckId;
	private String truckNumber;
	private int maxLoad;
	
	//getter and setter
	//constructor
	
	
	
}

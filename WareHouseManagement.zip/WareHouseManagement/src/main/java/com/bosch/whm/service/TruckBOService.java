package com.bosch.whm.service;

public class TruckBOService {
	//implement all methods of TruckBO
}

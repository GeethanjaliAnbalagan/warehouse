package com.bosch.whm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class WareHouseManagementApplication {

	public static void main(String[] args) {
		SpringApplication.run(WareHouseManagementApplication.class, args);
	}

}

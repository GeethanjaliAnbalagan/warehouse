package com.bosch.whm.service;

public class InBoundRequesitionFormBOService {
	//implement all methods of InBoundRequesitionFormBO
}

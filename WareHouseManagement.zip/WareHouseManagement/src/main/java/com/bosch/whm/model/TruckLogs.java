package com.bosch.whm.model;

public class TruckLogs {

}

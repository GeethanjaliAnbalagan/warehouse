package com.bosch.whm.model;

public class InventoryMasterBO {


	//new inbound product 
	ProductInBoundBO productInBoundBO;
	public String addProduct(Product product)//epic 5

	//have to use ProductInBoundBO and implement it

	{
		return null;




	}




	public int increaseInventoryCount()//epic 5

	{	
		return 0;


	}

	public int inventoryCountUpdate()//epic 5
	{



		return 0;


	}


	public int inventoryCountDamage()//epic 5
	{



		return 0;


	}

	public String validateData()//epic 5

	{
		return null;

	}
	public int decreaseInventoryCount()//epic 5{

	{

		return 0;			

	}










}


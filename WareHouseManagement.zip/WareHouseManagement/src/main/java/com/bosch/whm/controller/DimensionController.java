package com.bosch.whm.controller;

public class DimensionController {


	public static void main(String[] args) {
		//call required service classes
	}

}

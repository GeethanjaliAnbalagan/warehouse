package com.bosch.whm.service;

public class InventoryBOService {
	//implement all methods of InventoryBO
}

package com.bosch.whm.model;

import java.io.*;

public class  OutBoundRequesitionForm {


	private  int       ProductCode;
	private String  ProductName;
	private  String  DeliveryLocation;

	//Create Parameterized constructor

	//Create getter and setter with toString





}

package com.bosch.whm.service;

public class UserBOService {
	//implement all methods of UserBO
}

package com.bosch.whm.model;
import java.util.ArrayList;
import java.util.List;

public class InBoundRequesitionFormBO {


	List<InBoundRequesitionForm> list=new ArrayList<InBoundRequesitionForm>();

	public String saveInBoundRequesition(InBoundRequesitionForm inBoundRequesitionForm )//epic-2{

	{
		return null;
	}

	public String editInBoundRequesition(InBoundRequesitionForm inBoundRequesitionForm) //using product code need to edit


	{
		return null;
//epic-2


	}

	public String userScan(Product product) {
		return null;//need to check productId


//epic-2

	}



}

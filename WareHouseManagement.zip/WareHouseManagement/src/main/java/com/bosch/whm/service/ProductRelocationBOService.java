package com.bosch.whm.service;

public final class ProductRelocationBOService {
	//implement all methods of ProductRelocationBO
}

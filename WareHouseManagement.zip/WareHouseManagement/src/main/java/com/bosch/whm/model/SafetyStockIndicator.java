package com.bosch.whm.model;

import java.util.List;

//import product class
public class SafetyStockIndicator {



	private int sno;
	private Product product;
	private int minimumExpectedStock;
	private int thresholdDefined;


	//getter and setter
	//constructor
	//tostring

	//System to predict the stock level and alert the manager


}
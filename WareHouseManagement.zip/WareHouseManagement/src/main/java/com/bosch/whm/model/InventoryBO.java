package com.bosch.whm.model;

public class InventoryBO {

	public void validateData()//epic 4
	{   

		//call the inventory validate data method


	}


	public String updateInventryCount()//epic 5

	{
		return null;
		//update your inventrycount

	}




}


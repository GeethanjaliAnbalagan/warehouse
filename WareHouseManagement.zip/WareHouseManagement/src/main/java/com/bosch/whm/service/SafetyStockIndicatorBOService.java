package com.bosch.whm.service;

public class SafetyStockIndicatorBOService {
	//implement all methods of SafetyStockIndicatorBO
}

package com.bosch.whm.service;

public class DimensionBOService {
//implement all methods of DimensionBO
}

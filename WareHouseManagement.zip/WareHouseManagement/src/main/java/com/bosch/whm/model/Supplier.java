package com.bosch.whm.model;

public class Supplier {
	
	   
    private String supplierName;
    private String supplierLocation;
   
    


    public Supplier(){}

    //Create Parameterized constructor
 
    //Create getter setter with toString

}

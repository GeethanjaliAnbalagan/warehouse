package com.bosch.whm.model;

public class Dimension {
	
    private double length;
     private double width;
      private double height;

      public Dimension(){}

    //Create Parameterized constructor
 
    //Create getter setter with toString

	
}



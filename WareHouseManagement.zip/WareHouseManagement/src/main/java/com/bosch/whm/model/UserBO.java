package com.bosch.whm.model;

import java.util.ArrayList;
import java.util.List;

//import User class
class UserVO{



	List<User> list=new ArrayList<User>();
	public String createUser(User user)//epic-1{
	{
		return null;


}

public boolean authenticate(User user) {
	return false;//epic-1{


}

public String modifyeUserProfile(User user){
	return null;
//need to update roll name,email using userID


//epic-1
}

	public String deleteUser(int userId) {
		return null;//epic-1{

}




public void userLandingPage(User user){//epic-1}//Logic as per the user module(eg:Admin-1,manager-2,WH Operator-3)
	{}


}}
package com.bosch.whm.service;

public class LocationAnalyzerBOService {
	//implement all methods of LocationAnalyzerBO
}

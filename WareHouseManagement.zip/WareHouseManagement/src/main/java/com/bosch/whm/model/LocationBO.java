package com.bosch.whm.model;

import java.util.ArrayList;
import java.util.List;

public class LocationBO {


	List<Location> list=new ArrayList<Location>();


	public void addLocation(Location location)//epic2


	{



	}



	//logic related to set Status

	public void setStatus(Location location)//epic2

	{//basing on locationId need to change statuscode



	}


	public String updateLocation(Location location)//epic 3
	{}//

	public void deallocate() //epic4
	{}
}

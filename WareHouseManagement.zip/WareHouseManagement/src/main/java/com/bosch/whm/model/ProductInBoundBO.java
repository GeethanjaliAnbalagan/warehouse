package com.bosch.whm.model;

import java.util.ArrayList;
import java.util.List;

public class ProductInBoundBO {



	List<Product> list=new ArrayList<Product>();
	public String createProduct(Product product){



	}

	//logic related to get Product

	public Product getProduct(int productCode)//epic 2

	{
		return null;



	}
	public String updateStock(Product product) //epic 2
	{
		return null;//basing on productCode need to update stock





	}
	public String updateproduct(Product Product)//epic 3

	{
		return null;}//using product code need to update product details like name,weight

}


package com.bosch.whm.model;

import java.io.*;

public class Inventory{
  
  int ProductCode;
  String ProductName;
   String TransferType;
String CurrentLocation;
String ScannedLocation;


// create setters and getters
// create required constructors
}

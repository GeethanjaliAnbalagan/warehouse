package com.bosch.whm.model;

public class InBoundRequesitionForm {
	
    private Product product;
    private Supplier supplier;
    private int ProductQty; 
    private int batchNo;
    //String or DateTime
    private String dateOfPOIssuance;
    private int purchaseOrderNo;
    //String or DateTime
    private String dateOfDelivery;
    


   
   
}

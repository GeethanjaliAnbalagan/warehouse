package com.bosch.whm.controller;

public class InBoundRequesitionFormController {




		public static void main(String[] args) {
			//call required service classes
		}




}

package com.bosch.whm.controller;

public class TruckController {
	public static void main(String[] args) {
		//call required service classes
	}
}

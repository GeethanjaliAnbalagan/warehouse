package com.bosch.whm.model;

public class TruckBO {

	public String requestTruck()//epic 6
	
	 {
	
		//Fill all the expected details about the product, 
		//delivery date and location
		
		
		//After filling the details, request submit the details
		return null;

		
		//send to ui page
		
	}
	
	public String tripStatus()//epic 6
	 {
		
		//Total Distance covered = 
		//Average Speed * Total time travelled
		
		// truck Is assigned, the status of the request changes to ‘Truck Assigned’
		
		//If the truck is loaded and starts it’s trip, status changed to ‘On the way’
		
		//If the truck reaches the destination and delivers the 
		//products, the status changes to ‘Trip Completed’
		return null;
		
		//The status is defined bases on the distance travelled/covered by the truck.

		// Status of the truck will be sent as text files to the 
		//requestor through an email on daily basis.
	}
}


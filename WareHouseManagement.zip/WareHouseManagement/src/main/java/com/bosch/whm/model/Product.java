package com.bosch.whm.model;

public class Product {

	private int productCode;
	private String name;
	private int currentStock;
	private Dimension dimension;
	private double weight;



	public Product(){}

	//Create Parameterized constructor

	//Create getter setter with toString







}








package com.bosch.whm.model;


public class User {
	
    private String name;
    private int UserType;
    private int empId;
    private String email;
    private String password; 
  
 //

    public User(){}

    //Create Parameterized constructor
 
    //Create getter setter with toString


   

	
}






        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        

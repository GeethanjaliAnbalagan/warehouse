package com.bosch.whm;

public class LocationBOTest {

}

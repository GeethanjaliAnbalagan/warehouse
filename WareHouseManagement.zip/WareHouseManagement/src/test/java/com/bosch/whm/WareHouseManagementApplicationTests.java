package com.bosch.whm;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WareHouseManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
